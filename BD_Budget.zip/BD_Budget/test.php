<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    
    
        <div style="background-color:rgb(247, 48, 131); height: 400px;width: 950px;margin-top: 100px;margin-left: 150px;float: left;">
        <h1 style="color:white">ITEM HAS BEEN ADDED</h1>
        <h2>YOUR CART :</h2>
          <?php 
          
          echo "<table border='1' width='700' cellspacing='0' bgcolor='white'>";
          echo "<tr'>";
          echo"<th>User ID</th>";
          echo "<th>Cart ID</th>";
          echo "<th>Product Name</th>";
          echo "</tr>";
          echo "<tr'>";
          echo"<td>1</td>";
          echo "<td>2</td>";
          echo "<td>GGkjhkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk</td>";
          echo "</tr>";
          echo "</table>";
          
          
          
          
          ?>
         
         
         

        </div> 
        
        



    
</body>
</html>